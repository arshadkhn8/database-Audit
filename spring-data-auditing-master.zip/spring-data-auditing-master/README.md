# spring-data-auditing
How to implement auditing using spring data jpa
